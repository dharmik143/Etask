<!DOCTYPE html>
<html>
<head>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

    <style>
        .error{
            color: #FF0000;
        }
    </style>

</head>
<body>

<div class="container mt-4">
    <table class="table table-bordered" id="clients" width="100%" cellspacing="0">
        <thead>
        <tr>
            <th>#</th>
            <th>Emp</th>
            <th>FirstName</th>
            <th>LastName</th>
            <th>joining_date</th>
        </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
    <div class="card">
        <div class="card-header text-center font-weight-bold">
            <h2>Laravel 8 Ajax Post Form Data on Controller with jQuery Validation Example</h2>
        </div>
        <div class="card-body">
            <form name="emp" id="emp" method="post" action="javascript:void(0)">
                @csrf

                <div class="form-group">
                    <label for="exampleInputEmail1">First Name</label>
                    <input type="text" id="first_name" name="first_name" class="form-control">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Last Name</label>
                    <input type="text" id="last_name" name="last_name" class="form-control">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Joining Date</label>
                    <input type="date" id="joining_date" name="joining_date" class="form-control">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Profile Image</label>
                    <input type="file" id="profile_image" name="profile_image" class="form-control">
                </div>

                <button type="submit" class="btn btn-primary" id="submit">Submit</button>
            </form>
        </div>
    </div>
</div>
<link href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" rel="stylesheet">
{{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>--}}
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function(){
        $.fn.dataTable.ext.errMode = 'throw';
        $('#clients').DataTable({
            "ajax":{
                "url": "{{ route('client-list') }}",
                "type": "POST",
                dataType:"json",
                "data": function(d){
                    d._token = "{{csrf_token()}}",
                        d.id=$("#id").val();
                    d.employee_code=$("#employee_code").val();
                    d.first_name=$("#first_name").val();
                    d.last_name=$("#emailast_namel").val();
                    d.joining_date=$("#joining_date").val();
                }
            },
            "searching": true,
            "processing": true,
            "serverSide": true,
            "order": [[ 0, 'DESC' ]],
            "columns": [
                {"name": "id"},
                {"name": "employee_code"},
                {"name": "first_name"},
                {"name": "last_name"},
                {"name": "joining_date"},
            ],
            "dom": '<"top"rf>t<"bottom"pli>',
        });
    });
    if ($("#emp").length > 0) {
        $("#emp").validate({
            rules: {
                first_name: {
                    required: true,
                    maxlength: 50
                },
                last_name: {
                    required: true,
                    maxlength: 50,
                },
                joining_date: {
                    required: true,
                    maxlength: 50
                },
                profile_image: {
                    required: true,
                    maxlength: 50
                },
            },
            messages: {
                first_name: {
                    required: "Please enter name",
                    maxlength: "Your name maxlength should be 50 characters long."
                },
                last_name: {
                    required: "Please enter valid email",
                    maxlength: "The email name should less than or equal to 50 characters",
                },
                joining_date: {
                    required: "Please enter message",
                    maxlength: "Your message name maxlength should be 300 characters long."
                },
                profile_image: {
                    required: "Please enter message",
                    maxlength: "Your message name maxlength should be 300 characters long."
                },
            },
            submitHandler: function(form) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $('#submit').html('Please Wait...');
                $("#submit"). attr("disabled", true);

                $.ajax({
                    url: "{{url('store-data')}}",
                    type: "POST",
                    data: $('#emp').serialize(),
                    success: function( response ) {
                        $('#submit').html('Submit');
                        $("#submit"). attr("disabled", false);
                        alert('Ajax form has been submitted successfully');
                        document.getElementById("emp").reset();
                    }
                });
            }
        })
    }
</script>
</body>
</html>