<?php

namespace App\Http\Controllers;

use App\Http\Requests\UpdateEmployeeRequest;
use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(request()->ajax())
        {
            $emp = new Employee();

            if($request->search['value'])
            {
                $search = $request->search['value'];
                $emp = $emp->where('first_name', 'like', '%' .$search . '%')->Orwhere('email', 'like', '%' .$search . '%')->Orwhere('last_name', 'like', '%' .$search . '%');
            }
            $order=	$request->columns[$request->order[0]['column']]['name'];
            $dir =$request->order[0]['dir'];
            if($order == 'name'){
                $emp =  $emp->orderBy('name', $dir);
            }
            else{
                $emp =  $emp->orderBy($order, $dir);
            }

            $offset = $request->start ?: 0;
            $limit = $request->length ?: 10;

            $emp = $emp->orderBy('id', 'desc');

            $clientTotal = $emp->get();

            $emp = $emp->skip($offset)->take($limit)->get();

            $clientList= [];

            if(!empty($emp)){
                foreach ($emp as $client){

                    $currentData= [];
                    $currentData[]=$client->id;
                    $currentData[]=$client->employee_code;
                    $currentData[]=$client->first_name;
                    $currentData[]=$client->last_name;
                    $currentData[]=$client->joining_date;

                    $action = '<div class="text-right">';
                    $action .= ' </div>';
                    $currentData[] = $action;
                    $clientList[] = $currentData;
                }
            }

            $json_data = [
                "draw" => intval($request['draw']),
                "data" => $clientList,
                "recordsTotal" => count($clientTotal),
                "recordsFiltered" => count($clientTotal)
            ];
            return response()->json($json_data);
        }
        return view('emp-form');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    public function store(Request $request)
    {

        $validatedData = $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'joining_date' => 'required',
            'profile_image' => 'nullable|image|size:2048',
        ]);

        $save = new Employee;

        $save->employee_code = Employee::getNextEmployeeNumber();
        $save->first_name = $request->first_name;
        $save->last_name = $request->last_name;
        $save->joining_date = $request->joining_date;
        $save->profile_image = $request->profile_image;

        $save->save();

        return redirect('emp-form')->with('status', 'Ajax Form Data Has Been validated and store into database');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function show(Employee $employee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function edit(Employee $employee)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateEmployeeRequest  $request
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateEmployeeRequest $request, Employee $employee)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function destroy(Employee $employee)
    {
        //
    }
}
