<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    use HasFactory;
    protected  $fillable = [
        'employee_code', 'first_name', 'last_name', 'joining_date', 'profile_image'
    ];

    public static function getNextEmployeeNumber()
    {

        $lastEmployee = Employee::orderBy('created_at', 'desc')->first();

        if ( ! $lastEmployee )

            $number = 0;
        else
            $number = substr($lastEmployee->order_id, 3);

        return 'EMP' . sprintf('%06d', intval($number) + 1);
    }
}
